<h1>Instrukcja używania web aplikacji</h1>

<h2>Przygotowanie</h2>
- Dla uruchumienia jest potrzebny zainstalowany Docker

<h2>Uruchomienie</h2>

- docker build . -t test_app

- docker run -p 8000:8000 test_app

Po uruchomieniu kontainera aplikacja będzie uruchomiona pod adressem localhost:8000
